import "dotenv/config";
import Database from "better-sqlite3";
import express from "express";
import cron from "node-cron";
import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  MessageFlags,
  PermissionFlagsBits,
} from "discord.js";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, "data");
fs.mkdirSync(DATA_DIR, { recursive: true });

const token = process.env.BOT_TOKEN?.trim();
if (!token) {
  throw new Error(
    "BOT_TOKEN não configurado. Adicione-o em Replit Secrets ou no arquivo local .env.",
  );
}

const DEFAULTS = {
  prefix: ".",
  embedColor: "#B5121B",
  author: "Diário América",
  timezone: "America/Sao_Paulo",
  rankingChannelId: "",
  dailyRoleId: "1561586136638300171",
  emojis: {
    vitoria: "🏆",
    kill: "⚔️",
    carteira: "💵",
    ranking: "🏆",
    perfil: "👤",
    vaga: "🛒",
    suporte: "🎫",
    fechar: "🔒",
    assumir: "☑️",
  },
};

const PIX_KEY = "1ea4021e-fc4b-42b0-9ae9-29c174a984e4";
const VACANCY_CAPACITY = 50;
const VACANCY_PRICE_CENTS = 600;

const db = new Database(path.join(DATA_DIR, "americar-rp.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
  CREATE TABLE IF NOT EXISTS profiles (
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    wins INTEGER NOT NULL DEFAULT 0 CHECK (wins >= 0),
    kills INTEGER NOT NULL DEFAULT 0 CHECK (kills >= 0),
    diaries INTEGER NOT NULL DEFAULT 0 CHECK (diaries >= 0),
    spent_cents INTEGER NOT NULL DEFAULT 0 CHECK (spent_cents >= 0),
    wallet_cents INTEGER NOT NULL DEFAULT 0 CHECK (wallet_cents >= 0),
    PRIMARY KEY (guild_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS stats_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    event_type TEXT NOT NULL CHECK (event_type IN ('win', 'kill')),
    amount INTEGER NOT NULL CHECK (amount > 0),
    day_key TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE INDEX IF NOT EXISTS stats_events_daily
    ON stats_events (guild_id, day_key, event_type, user_id);
  CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id TEXT NOT NULL,
    setting_key TEXT NOT NULL,
    setting_value TEXT NOT NULL,
    PRIMARY KEY (guild_id, setting_key)
  );
  CREATE TABLE IF NOT EXISTS staff_members (
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    added_by TEXT NOT NULL,
    added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (guild_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS tickets (
    channel_id TEXT PRIMARY KEY,
    guild_id TEXT NOT NULL,
    owner_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed')),
    claimed_by TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    closed_at TEXT
  );
  CREATE INDEX IF NOT EXISTS tickets_open_by_owner
    ON tickets (guild_id, owner_id, status);
  CREATE TABLE IF NOT EXISTS vacancy_carts (
    channel_id TEXT PRIMARY KEY,
    guild_id TEXT NOT NULL,
    owner_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open'
      CHECK (status IN ('open', 'confirmed', 'cancelled')),
    slot_number INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    closed_at TEXT
  );
  CREATE UNIQUE INDEX IF NOT EXISTS vacancy_carts_one_open_per_owner
    ON vacancy_carts (guild_id, owner_id) WHERE status = 'open';
  CREATE INDEX IF NOT EXISTS vacancy_carts_by_owner
    ON vacancy_carts (guild_id, owner_id, status);
  CREATE TABLE IF NOT EXISTS confirmed_vacancies (
    guild_id TEXT NOT NULL,
    slot_number INTEGER NOT NULL CHECK (slot_number BETWEEN 1 AND 50),
    user_id TEXT NOT NULL,
    confirmed_by TEXT NOT NULL,
    confirmed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (guild_id, slot_number),
    UNIQUE (guild_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
    paid_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS daily_runs (
    guild_id TEXT NOT NULL,
    day_key TEXT NOT NULL,
    message_id TEXT NOT NULL,
    PRIMARY KEY (guild_id, day_key)
  );
`);

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

const scheduledGuilds = new Map();

function getSettings(guildId) {
  const rows = db
    .prepare("SELECT setting_key, setting_value FROM guild_settings WHERE guild_id = ?")
    .all(guildId);
  const settings = { ...DEFAULTS, emojis: { ...DEFAULTS.emojis } };
  for (const row of rows) {
    if (row.setting_key.startsWith("emoji.")) {
      settings.emojis[row.setting_key.slice("emoji.".length)] = row.setting_value;
    } else if (row.setting_key === "embedColor") {
      settings.embedColor = row.setting_value;
    } else if (row.setting_key === "author") {
      settings.author = row.setting_value;
    } else if (row.setting_key === "prefix") {
      settings.prefix = row.setting_value;
    } else if (row.setting_key === "timezone") {
      settings.timezone = row.setting_value;
    } else if (row.setting_key === "rankingChannelId") {
      settings.rankingChannelId = row.setting_value;
    } else if (row.setting_key === "dailyRoleId") {
      settings.dailyRoleId = row.setting_value;
    }
  }
  return settings;
}

function setSetting(guildId, key, value) {
  db.prepare(
    `INSERT INTO guild_settings (guild_id, setting_key, setting_value)
     VALUES (?, ?, ?)
     ON CONFLICT(guild_id, setting_key) DO UPDATE SET setting_value = excluded.setting_value`,
  ).run(guildId, key, String(value));
}

function ensureProfile(guildId, userId) {
  db.prepare(
    "INSERT OR IGNORE INTO profiles (guild_id, user_id) VALUES (?, ?)",
  ).run(guildId, userId);
  return db
    .prepare("SELECT * FROM profiles WHERE guild_id = ? AND user_id = ?")
    .get(guildId, userId);
}

function getProfile(guildId, userId) {
  return ensureProfile(guildId, userId);
}

function getEmbedColor(settings) {
  return Number.parseInt(settings.embedColor.slice(1), 16);
}

function formatMoney(cents) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(cents / 100);
}

function parseMoneyToCents(value, allowZero = false) {
  const clean = value.replace(/^R\$\s*/i, "").replace(/\s/g, "");
  if (!clean || !/^[\d.,]+$/.test(clean)) return null;
  let normalized;
  if (clean.includes(",")) {
    normalized = clean.replace(/\./g, "").replace(",", ".");
  } else if (/^\d{1,3}(?:\.\d{3})+$/.test(clean)) {
    normalized = clean.replace(/\./g, "");
  } else {
    normalized = clean;
  }
  const amount = Number(normalized);
  if (
    !Number.isFinite(amount) ||
    amount < 0 ||
    (!allowZero && amount === 0) ||
    amount > 1_000_000_000
  ) {
    return null;
  }
  return Math.round(amount * 100);
}

function toDayKey(date, timezone) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: timezone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const part = (type) => parts.find((item) => item.type === type)?.value;
  return `${part("year")}-${part("month")}-${part("day")}`;
}

function previousDayKey(todayKey) {
  const [year, month, day] = todayKey.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day) - 86_400_000)
    .toISOString()
    .slice(0, 10);
}

function isAdmin(member) {
  return member.permissions.has(PermissionFlagsBits.Administrator);
}

function isStaff(guildId, userId) {
  return Boolean(
    db
      .prepare("SELECT 1 FROM staff_members WHERE guild_id = ? AND user_id = ?")
      .get(guildId, userId),
  );
}

function canManageDiary(member, userId) {
  return isAdmin(member) || isStaff(member.guild.id, userId);
}

function mentionTarget(message) {
  return message.mentions.users.first() ?? null;
}

function parsePositiveInteger(value, fallback = null, max = 1_000_000) {
  if (value === undefined && fallback !== null) return fallback;
  if (!/^\d+$/.test(value ?? "")) return null;
  const result = Number(value);
  if (!Number.isSafeInteger(result) || result <= 0 || result > max) return null;
  return result;
}

function resolveButtonEmoji(value) {
  const custom = value.match(/^<(?<animated>a?):(?<name>\w+):(?<id>\d+)>$/);
  if (custom?.groups) {
    return {
      id: custom.groups.id,
      name: custom.groups.name,
      animated: custom.groups.animated === "a",
    };
  }
  return { name: value };
}

function safeChannelSlug(username, fallback) {
  const slug = username
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 75);
  return slug || fallback;
}

function sleep(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function ensurePrivateCategory(guild, categoryName) {
  const existing = guild.channels.cache.find(
    (channel) =>
      channel.type === ChannelType.GuildCategory &&
      channel.name.toLowerCase() === categoryName.toLowerCase(),
  );
  if (existing) return existing;

  const overwrites = [
    {
      id: guild.roles.everyone.id,
      deny: [PermissionFlagsBits.ViewChannel],
    },
  ];
  if (client.user) {
    overwrites.push({
      id: client.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageChannels,
      ],
    });
  }
  const staff = db
    .prepare("SELECT user_id FROM staff_members WHERE guild_id = ?")
    .all(guild.id);
  for (const member of staff) {
    overwrites.push({
      id: member.user_id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
      ],
    });
  }
  return guild.channels.create({
    name: categoryName,
    type: ChannelType.GuildCategory,
    permissionOverwrites: overwrites,
    reason: `Categoria privada de ${categoryName}`,
  });
}

function privateChannelOverwrites(guild, ownerId) {
  const overwrites = [
    {
      id: guild.roles.everyone.id,
      deny: [PermissionFlagsBits.ViewChannel],
    },
    {
      id: ownerId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks,
      ],
    },
  ];
  if (client.user) {
    overwrites.push({
      id: client.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageChannels,
      ],
    });
  }
  const staff = db
    .prepare("SELECT user_id FROM staff_members WHERE guild_id = ?")
    .all(guild.id);
  for (const member of staff) {
    overwrites.push({
      id: member.user_id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageMessages,
      ],
    });
  }
  return overwrites;
}

function profileEmbed(guild, user, settings) {
  const profile = getProfile(guild.id, user.id);
  const member = guild.members.cache.get(user.id);
  const displayName = member?.displayName ?? user.globalName ?? user.username;
  const winrate =
    profile.diaries > 0
      ? `${((profile.wins / profile.diaries) * 100).toFixed(1).replace(".", ",")}%`
      : "0,0%";

  return new EmbedBuilder()
    .setColor(getEmbedColor(settings))
    .setAuthor({ name: settings.author })
    .setTitle(`Estatísticas: ${displayName}`)
    .setDescription(`<@${user.id}>`)
    .addFields(
      {
        name: `${settings.emojis.vitoria} Vitórias (Booyahs)`,
        value: String(profile.wins),
        inline: true,
      },
      {
        name: `${settings.emojis.kill} Total de Kills`,
        value: String(profile.kills),
        inline: true,
      },
      {
        name: "🎮 Diários Jogados",
        value: String(profile.diaries),
        inline: true,
      },
      { name: "📈 Winrate", value: winrate, inline: true },
      {
        name: "💰 Gasto em Vagas",
        value: formatMoney(profile.spent_cents),
        inline: true,
      },
      {
        name: `${settings.emojis.carteira} Recebido na Carteira / Saldo`,
        value: formatMoney(profile.wallet_cents),
        inline: true,
      },
    )
    .setThumbnail(user.displayAvatarURL({ size: 256 }))
    .setFooter({ text: "América RP" })
    .setTimestamp();
}

function rankingPanel(settings) {
  const embed = new EmbedBuilder()
    .setColor(getEmbedColor(settings))
    .setAuthor({ name: settings.author })
    .setTitle("🏆 Ranking América RP")
    .setDescription(
      "Consulte os melhores jogadores ou confira suas estatísticas pessoais.",
    )
    .setFooter({ text: "América RP • Estatísticas atualizadas em tempo real" });
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("amrp:ranking")
      .setLabel("Ranking")
      .setEmoji(resolveButtonEmoji(settings.emojis.ranking))
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("amrp:profile")
      .setLabel("Meu Perfil")
      .setEmoji(resolveButtonEmoji(settings.emojis.perfil))
      .setStyle(ButtonStyle.Secondary),
  );
  return { embeds: [embed], components: [row] };
}

function ticketPanel(settings) {
  const embed = new EmbedBuilder()
    .setColor(0xff0000)
    .setTitle("Atendimento Diário América")
    .setDescription(
      "Precisa de ajuda ou teve algum problema? Nossa equipe está pronta para te atender. Clique no botão abaixo.",
    )
    .setFooter({ text: "Equipe Ádministrativa - AMRP" });
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("amrp:ticket:create")
      .setLabel("Suporte")
      .setEmoji(resolveButtonEmoji(settings.emojis.suporte))
      .setStyle(ButtonStyle.Danger),
  );
  return { embeds: [embed], components: [row] };
}

function vacancyPanel(settings) {
  const price = formatMoney(VACANCY_PRICE_CENTS).replace(/\u00a0/g, " ");
  const embed = new EmbedBuilder()
    .setColor(0xff0000)
    .setAuthor({ name: "Diário América" })
    .setDescription(
      [
        `○ 💰 **Inscrição:** ${price}`,
        "○ 💀 **Valor por kill:** R$ 3,00",
        "○ 👑 **Vitória:** R$ 10,00 + valor das kills.",
        "",
        "○ Não ganhou, mas conseguiu **1 kill** e ficou entre os **30 últimos a morrerem** → recebe **R$ 3,00**.",
        "○ Ganhou com **4 kills** → recebe **R$ 22,00** (R$ 10,00 + R$ 12,00 das kills).",
        "",
        "○ **Como Comprar Vaga:**",
        "Clique no botão abaixo e efetue o pagamento na chave pix fornecida pelo bot, após isso espere que um adm confirme sua participação.",
      ].join("\n"),
    )
    .setFooter({ text: "Equipe Ádministrativa - AMRP" });
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("amrp:vagas:buy")
      .setLabel("Comprar Vaga")
      .setEmoji(resolveButtonEmoji(settings.emojis.vaga))
      .setStyle(ButtonStyle.Danger),
  );
  return { embeds: [embed], components: [row] };
}

function vacancyPaymentEmbed() {
  const price = formatMoney(VACANCY_PRICE_CENTS).replace(/\u00a0/g, " ");
  return new EmbedBuilder()
    .setColor(0xff0000)
    .setAuthor({ name: "Garantir Vaga - América Diário" })
    .setDescription(
      [
        "Seja bem-vindo(a) à área de garantir sua vaga pro diário. Para confirmar a sua participação e garantir a sua vaga, siga o passo a passo abaixo:",
        "",
        `**1. Efetue o pagamento no valor de ${price}.**`,
        `**2. Chave PIX:** \`${PIX_KEY}\``,
        "**3. Envie o comprovante abaixo.**",
        "",
        "**Próximos passos:**",
        "Após o envio, por favor, aguarde a validação. Um de nossos administradores confirmará o recebimento do seu pagamento em breve.",
        "Assim que a confirmação for feita, sua vaga estará 100% garantida. Depois disso, basta aguardar por novas informações e orientações sobre o início do diário.",
      ].join("\n"),
    )
    .setFooter({ text: "Equipe Ádministrativa - América RP" });
}

function ticketActions(settings) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("amrp:ticket:close")
      .setLabel("Fechar Ticket")
      .setEmoji(resolveButtonEmoji(settings.emojis.fechar))
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId("amrp:ticket:claim")
      .setLabel("Assumir Ticket")
      .setEmoji(resolveButtonEmoji(settings.emojis.assumir))
      .setStyle(ButtonStyle.Success),
  );
}

function vacancyCartActions(settings) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("amrp:vagas:cancel")
      .setLabel("Cancelar / Fechar Carrinho")
      .setEmoji(resolveButtonEmoji(settings.emojis.fechar))
      .setStyle(ButtonStyle.Secondary),
  );
}

function resetVacanciesActions(userId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`amrp:vagas:reset:confirm:${userId}`)
      .setLabel("Confirmar reset")
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId(`amrp:vagas:reset:cancel:${userId}`)
      .setLabel("Cancelar")
      .setStyle(ButtonStyle.Secondary),
  );
}

function topPlayers(guildId, limit = 10) {
  return db
    .prepare(
      `SELECT user_id, wins, kills, diaries
       FROM profiles
       WHERE guild_id = ?
       ORDER BY wins DESC, kills DESC, diaries DESC
       LIMIT ?`,
    )
    .all(guildId, limit);
}

function dailyPlayers(guildId, dayKey) {
  return db
    .prepare(
      `SELECT user_id,
              SUM(CASE WHEN event_type = 'win' THEN amount ELSE 0 END) AS wins,
              SUM(CASE WHEN event_type = 'kill' THEN amount ELSE 0 END) AS kills
       FROM stats_events
       WHERE guild_id = ? AND day_key = ?
       GROUP BY user_id
       HAVING SUM(amount) > 0
       ORDER BY wins DESC, kills DESC
       LIMIT 10`,
    )
    .all(guildId, dayKey);
}

function rankingEmbed(guild, settings) {
  const entries = topPlayers(guild.id);
  const description = entries.length
    ? entries
        .map(
          (player, index) =>
            `**${index + 1}.** <@${player.user_id}> — ${settings.emojis.vitoria} **${player.wins}** vitórias`,
        )
        .join("\n")
    : "Ainda não há vitórias registradas.";

  return new EmbedBuilder()
    .setColor(getEmbedColor(settings))
    .setAuthor({ name: settings.author })
    .setTitle(`${settings.emojis.ranking} Top 10 — Mais Vitórias`)
    .setDescription(description)
    .setFooter({ text: "Ranking geral • América RP" })
    .setTimestamp();
}

async function postDailyRanking(guild) {
  const settings = getSettings(guild.id);
  if (!settings.rankingChannelId) {
    console.warn(`[ranking] Canal diário não configurado para ${guild.name}.`);
    return;
  }

  const today = toDayKey(new Date(), settings.timezone);
  const dayKey = previousDayKey(today);
  const alreadyPosted = db
    .prepare("SELECT 1 FROM daily_runs WHERE guild_id = ? AND day_key = ?")
    .get(guild.id, dayKey);
  if (alreadyPosted) return;

  const channel = await guild.channels.fetch(settings.rankingChannelId);
  if (!channel?.isTextBased() || !("send" in channel)) {
    console.error(
      `[ranking] Canal diário inválido ou inacessível em ${guild.name}.`,
    );
    return;
  }

  const players = dailyPlayers(guild.id, dayKey);
  const embed = new EmbedBuilder()
    .setColor(getEmbedColor(settings))
    .setAuthor({ name: settings.author })
    .setTitle("🏆 TOP Jogadores do Dia")
    .setDescription(
      players.length
        ? players
            .map(
              (player, index) =>
                `**${index + 1}.** <@${player.user_id}> — ${settings.emojis.vitoria} **${player.wins}** vitórias · ${settings.emojis.kill} **${player.kills}** kills`,
            )
            .join("\n")
        : "Nenhuma vitória ou kill foi registrada neste dia.",
    )
    .setFooter({ text: `Período: ${dayKey} • América RP` })
    .setTimestamp();

  const sent = await channel.send({ embeds: [embed] });
  db.prepare(
    "INSERT OR IGNORE INTO daily_runs (guild_id, day_key, message_id) VALUES (?, ?, ?)",
  ).run(guild.id, dayKey, sent.id);
  console.info(
    `[ranking] Enviado para ${guild.name}: dados de ${dayKey}, ${players.length} jogador(es).`,
  );
}

function scheduleGuild(guild) {
  scheduledGuilds.get(guild.id)?.stop();
  const timezone = getSettings(guild.id).timezone;
  const task = cron.schedule(
    "0 0 * * *",
    () => {
      postDailyRanking(guild).catch((error) =>
        console.error(`[ranking] Falha em ${guild.name}:`, error),
      );
    },
    { timezone },
  );
  scheduledGuilds.set(guild.id, task);
  console.info(`[cron] Ranking de ${guild.name} agendado para 00:00 (${timezone}).`);
}

async function setRanking(message, settings) {
  const panel = await message.channel.send(rankingPanel(settings));
  try {
    await panel.pin();
    await message.reply("Painel de ranking enviado e fixado neste canal.");
  } catch (error) {
    console.warn("[ranking] O painel foi enviado, mas não pôde ser fixado:", error);
    await message.reply(
      "Painel enviado, mas não consegui fixá-lo. Dê ao bot a permissão **Gerenciar mensagens** para fixar.",
    );
  }
}

async function createTicket(interaction, settings) {
  const guild = interaction.guild;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const openTicket = db
    .prepare(
      "SELECT channel_id FROM tickets WHERE guild_id = ? AND owner_id = ? AND status = 'open'",
    )
    .get(guild.id, interaction.user.id);

  if (openTicket) {
    const existing = await guild.channels.fetch(openTicket.channel_id).catch(() => null);
    if (existing) {
      await interaction.editReply({
        content: `Você já tem um ticket aberto: ${existing}.`,
      });
      return;
    }
    db.prepare("UPDATE tickets SET status = 'closed' WHERE channel_id = ?").run(
      openTicket.channel_id,
    );
  }

  const category = await ensurePrivateCategory(guild, "Ticket's");
  const slug = safeChannelSlug(interaction.user.username, interaction.user.id.slice(-6));

  const channel = await guild.channels.create({
    name: `🎫・${slug}`.slice(0, 100),
    type: ChannelType.GuildText,
    parent: category.id,
    topic: `Ticket de ${interaction.user.id}`,
    permissionOverwrites: privateChannelOverwrites(guild, interaction.user.id),
    reason: `Ticket de suporte aberto por ${interaction.user.tag}`,
  });

  db.prepare(
    "INSERT INTO tickets (channel_id, guild_id, owner_id) VALUES (?, ?, ?)",
  ).run(channel.id, guild.id, interaction.user.id);

  await channel.send({
    content: `<@${interaction.user.id}>`,
    embeds: [
      new EmbedBuilder()
        .setColor(getEmbedColor(settings))
        .setAuthor({ name: settings.author })
        .setTitle("Ticket de suporte")
        .setDescription(
          "Descreva o que aconteceu. A equipe responderá neste canal privado.",
        )
        .setTimestamp(),
    ],
    components: [ticketActions(settings)],
  });
  await interaction.editReply({
    content: `Seu ticket foi criado: ${channel}.`,
  });
}

async function createVacancyCart(interaction, settings) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const confirmed = db
    .prepare(
      "SELECT slot_number FROM confirmed_vacancies WHERE guild_id = ? AND user_id = ?",
    )
    .get(interaction.guildId, interaction.user.id);
  if (confirmed) {
    await interaction.editReply(
      `Sua vaga já está confirmada: **${confirmed.slot_number}/${VACANCY_CAPACITY}**.`,
    );
    return;
  }

  const existingCart = db
    .prepare(
      "SELECT channel_id FROM vacancy_carts WHERE guild_id = ? AND owner_id = ? AND status = 'open'",
    )
    .get(interaction.guildId, interaction.user.id);
  if (existingCart) {
    const channel = await interaction.guild.channels
      .fetch(existingCart.channel_id)
      .catch(() => null);
    if (channel) {
      await interaction.editReply(`Você já tem um carrinho aberto: ${channel}.`);
      return;
    }
    db.prepare("UPDATE vacancy_carts SET status = 'cancelled' WHERE channel_id = ?").run(
      existingCart.channel_id,
    );
  }

  const category = await ensurePrivateCategory(
    interaction.guild,
    "Carrinho's Vagas",
  );
  const slug = safeChannelSlug(
    interaction.user.username,
    interaction.user.id.slice(-6),
  );
  const channel = await interaction.guild.channels.create({
    name: `🛒・${slug}`.slice(0, 100),
    type: ChannelType.GuildText,
    parent: category.id,
    topic: `Carrinho de vaga de ${interaction.user.id}`,
    permissionOverwrites: privateChannelOverwrites(
      interaction.guild,
      interaction.user.id,
    ),
    reason: `Carrinho de vaga aberto por ${interaction.user.tag}`,
  });

  try {
    db.prepare(
      "INSERT INTO vacancy_carts (channel_id, guild_id, owner_id) VALUES (?, ?, ?)",
    ).run(channel.id, interaction.guildId, interaction.user.id);
  } catch (error) {
    await channel.delete("Carrinho duplicado; já existe outro em aberto").catch(() => {});
    const open = db
      .prepare(
        "SELECT channel_id FROM vacancy_carts WHERE guild_id = ? AND owner_id = ? AND status = 'open'",
      )
      .get(interaction.guildId, interaction.user.id);
    const existing = open
      ? await interaction.guild.channels.fetch(open.channel_id).catch(() => null)
      : null;
    if (existing) {
      await interaction.editReply(`Você já tem um carrinho aberto: ${existing}.`);
      return;
    }
    throw error;
  }

  await channel.send({
    content: `<@${interaction.user.id}>`,
    embeds: [vacancyPaymentEmbed()],
    components: [vacancyCartActions(settings)],
  });
  await interaction.editReply(`Seu carrinho foi criado: ${channel}.`);
}

const vacancyConfirmationLocks = new Set();

async function confirmVacancy(message, requestedUser) {
  const guild = message.guild;
  const currentCart = db
    .prepare(
      "SELECT owner_id FROM vacancy_carts WHERE channel_id = ? AND guild_id = ? AND status = 'open'",
    )
    .get(message.channel.id, guild.id);
  const targetId = requestedUser?.id ?? currentCart?.owner_id;
  if (!targetId || requestedUser?.bot) {
    await message.reply(
      `Mencione o comprador ou use \`${getSettings(guild.id).prefix}d\` dentro do carrinho.`,
    );
    return;
  }

  if (vacancyConfirmationLocks.has(guild.id)) {
    await message.reply("Outra confirmação de vaga está sendo processada. Tente novamente em instantes.");
    return;
  }
  vacancyConfirmationLocks.add(guild.id);

  let reservation;
  let targetMember;
  let role;
  let cartChannel;
  let cartChannelId;
  let roleWasAdded = false;
  let channelWasRenamed = false;
  let diaryIncremented = false;
  let oldChannelName;
  try {
    const alreadyConfirmed = db
      .prepare(
        "SELECT slot_number FROM confirmed_vacancies WHERE guild_id = ? AND user_id = ?",
      )
      .get(guild.id, targetId);
    if (alreadyConfirmed) {
      await message.reply(
        `<@${targetId}> já tem a vaga **${alreadyConfirmed.slot_number}/${VACANCY_CAPACITY}** confirmada.`,
      );
      return;
    }

    const cart = db
      .prepare(
        "SELECT channel_id FROM vacancy_carts WHERE guild_id = ? AND owner_id = ? AND status = 'open'",
      )
      .get(guild.id, targetId);
    if (!cart) {
      await message.reply(
        `Não encontrei um carrinho aberto para <@${targetId}>. A pessoa precisa clicar em **Comprar Vaga** primeiro.`,
      );
      return;
    }
    cartChannel = await guild.channels.fetch(cart.channel_id).catch(() => null);
    cartChannelId = cart.channel_id;
    if (!cartChannel?.isTextBased() || !("setName" in cartChannel)) {
      db.prepare("UPDATE vacancy_carts SET status = 'cancelled' WHERE channel_id = ?").run(
        cart.channel_id,
      );
      await message.reply("O canal do carrinho não existe mais. Peça ao jogador para abrir outro.");
      return;
    }

    targetMember = await guild.members.fetch(targetId).catch(() => null);
    if (!targetMember) {
      await message.reply("Não encontrei esse usuário como membro deste servidor.");
      return;
    }
    role = await guild.roles.fetch(getSettings(guild.id).dailyRoleId).catch(() => null);
    if (!role) {
      await message.reply(
        `O cargo configurado não foi encontrado. Um administrador deve ajustar com \`${getSettings(guild.id).prefix}cargoid [id]\`.`,
      );
      return;
    }
    const botMember =
      guild.members.me ?? (client.user ? await guild.members.fetch(client.user.id) : null);
    if (
      !botMember?.permissions.has(PermissionFlagsBits.ManageRoles) ||
      role.managed ||
      role.position >= botMember.roles.highest.position
    ) {
      await message.reply(
        "Não consigo entregar esse cargo. Verifique se tenho **Gerenciar cargos** e se meu cargo está acima do cargo do diário na hierarquia.",
      );
      return;
    }

    const highestSlot = db
      .prepare(
        "SELECT COALESCE(MAX(slot_number), 0) AS last_slot FROM confirmed_vacancies WHERE guild_id = ?",
      )
      .get(guild.id).last_slot;
    if (highestSlot >= VACANCY_CAPACITY) {
      await message.reply(`As ${VACANCY_CAPACITY} vagas já foram preenchidas.`);
      return;
    }
    reservation = { full: false, slot: highestSlot + 1 };

    const alreadyHadRole = targetMember.roles.cache.has(role.id);
    if (!alreadyHadRole) {
      await targetMember.roles.add(role, `Vaga ${reservation.slot}/${VACANCY_CAPACITY} confirmada por ${message.author.tag}`);
      roleWasAdded = true;
    }
    oldChannelName = cartChannel.name;
    const slug = safeChannelSlug(
      targetMember.user.username,
      targetMember.id.slice(-6),
    );
    await cartChannel.setName(`✅️・${slug}`.slice(0, 100));
    channelWasRenamed = true;
    const finalizeConfirmation = db.transaction(() => {
      db.prepare(
        "INSERT INTO confirmed_vacancies (guild_id, slot_number, user_id, confirmed_by) VALUES (?, ?, ?, ?)",
      ).run(guild.id, reservation.slot, targetId, message.author.id);
      const cartUpdate = db
        .prepare(
          "UPDATE vacancy_carts SET status = 'confirmed', slot_number = ? WHERE channel_id = ? AND status = 'open'",
        )
        .run(reservation.slot, cart.channel_id);
      if (cartUpdate.changes !== 1) {
        throw new Error("O carrinho deixou de estar aberto durante a confirmação.");
      }
      ensureProfile(guild.id, targetId);
      db.prepare(
        "UPDATE profiles SET diaries = diaries + 1 WHERE guild_id = ? AND user_id = ?",
      ).run(guild.id, targetId);
    });
    finalizeConfirmation();
    diaryIncremented = true;

    const confirmation = `✅ Vaga confirmada para <@${targetId}>! (Vaga ${reservation.slot}/${VACANCY_CAPACITY})`;
    await cartChannel.send(confirmation);
    if (message.channel.id !== cartChannel.id) {
      await message.reply(confirmation).catch((error) =>
        console.warn("[vagas] Não consegui responder no canal do comando:", error),
      );
    }
  } catch (error) {
    if (reservation && !reservation.full) {
      db.prepare(
        "DELETE FROM confirmed_vacancies WHERE guild_id = ? AND user_id = ?",
      ).run(guild.id, targetId);
    }
    if (diaryIncremented) {
      db.prepare(
        "UPDATE profiles SET diaries = diaries - 1 WHERE guild_id = ? AND user_id = ? AND diaries > 0",
      ).run(guild.id, targetId);
    }
    if (channelWasRenamed && cartChannel && oldChannelName) {
      await cartChannel.setName(oldChannelName).catch(() => {});
      if (cartChannelId) {
        db.prepare(
          "UPDATE vacancy_carts SET status = 'open', slot_number = NULL WHERE channel_id = ?",
        ).run(cartChannelId);
      }
    }
    if (roleWasAdded && targetMember && role) {
      await targetMember.roles.remove(role, "Confirmação de vaga cancelada após falha").catch(() => {});
    }
    throw error;
  } finally {
    vacancyConfirmationLocks.delete(guild.id);
  }
}

async function showConfirmedVacancies(message) {
  const rows = db
    .prepare(
      "SELECT slot_number, user_id FROM confirmed_vacancies WHERE guild_id = ? ORDER BY slot_number",
    )
    .all(message.guild.id);
  const bySlot = new Map(rows.map((row) => [row.slot_number, row.user_id]));
  const lines = Array.from({ length: VACANCY_CAPACITY }, (_, index) => {
    const slot = index + 1;
    const userId = bySlot.get(slot);
    return userId
      ? `**${slot}.** <@${userId}>`
      : `**${slot}.** — Disponível`;
  });
  const embed = new EmbedBuilder()
    .setColor(0xff0000)
    .setAuthor({ name: "Diário América" })
    .setTitle(`Lista Oficial de Confirmados — ${rows.length}/${VACANCY_CAPACITY}`)
    .setDescription(lines.join("\n"))
    .setFooter({ text: "América RP • Vagas do evento atual" });
  await message.reply({ embeds: [embed] });
}

async function handleVacancyCartInteraction(interaction, settings) {
  const cart = db
    .prepare("SELECT * FROM vacancy_carts WHERE channel_id = ? AND guild_id = ?")
    .get(interaction.channelId, interaction.guildId);
  if (!cart || !["open", "confirmed"].includes(cart.status)) {
    await interaction.reply({
      content: "Este carrinho não está mais ativo.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (
    interaction.user.id !== cart.owner_id &&
    !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator) &&
    !isStaff(interaction.guildId, interaction.user.id)
  ) {
    await interaction.reply({
      content: "Somente quem abriu o carrinho ou a equipe pode fechá-lo.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (interaction.customId === "amrp:vagas:cancel") {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("amrp:vagas:cancel:confirm")
        .setLabel("Confirmar fechamento")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId("amrp:vagas:cancel:keep")
        .setLabel("Manter carrinho")
        .setStyle(ButtonStyle.Secondary),
    );
    await interaction.reply({
      content: "Deseja cancelar ou fechar este carrinho?",
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (interaction.customId === "amrp:vagas:cancel:keep") {
    await interaction.update({
      content: "O carrinho continua aberto.",
      components: [],
    });
    return;
  }

  if (interaction.customId === "amrp:vagas:cancel:confirm") {
    if (cart.status === "open") {
      db.prepare(
        "UPDATE vacancy_carts SET status = 'cancelled', closed_at = CURRENT_TIMESTAMP WHERE channel_id = ?",
      ).run(cart.channel_id);
    } else {
      db.prepare(
        "UPDATE vacancy_carts SET closed_at = CURRENT_TIMESTAMP WHERE channel_id = ?",
      ).run(cart.channel_id);
    }
    await interaction.update({
      content: "Carrinho encerrado. O canal será removido.",
      components: [],
    });
    await interaction.channel.delete(`Carrinho encerrado por ${interaction.user.tag}`);
  }
}

async function handleVacancyResetInteraction(interaction) {
  const [, , , action, requesterId] = interaction.customId.split(":");
  if (requesterId !== interaction.user.id) {
    await interaction.reply({
      content: "Somente o administrador que iniciou este reset pode confirmá-lo.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({
      content: "Somente administradores podem resetar as vagas.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (action === "cancel") {
    await interaction.update({
      content: "O reset foi cancelado. A lista atual permanece intacta.",
      components: [],
    });
    return;
  }
  if (action === "confirm") {
    if (vacancyConfirmationLocks.has(interaction.guildId)) {
      await interaction.update({
        content: "Há uma confirmação de vaga em andamento. A lista não foi alterada; tente novamente.",
        components: [],
      });
      return;
    }
    const result = db
      .prepare("DELETE FROM confirmed_vacancies WHERE guild_id = ?")
      .run(interaction.guildId);
    await interaction.update({
      content: `Lista zerada: ${result.changes} confirmação(ões) removida(s). Os cargos já entregues aos jogadores não foram removidos.`,
      components: [],
    });
  }
}

async function handleTicketInteraction(interaction, settings) {
  const ticket = db
    .prepare(
      "SELECT * FROM tickets WHERE channel_id = ? AND guild_id = ?",
    )
    .get(interaction.channelId, interaction.guildId);

  if (!ticket || ticket.status !== "open") {
    await interaction.reply({
      content: "Este ticket não está aberto.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (interaction.customId === "amrp:ticket:claim") {
    if (
      !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator) &&
      !isStaff(interaction.guildId, interaction.user.id)
    ) {
      await interaction.reply({
        content: "Somente a equipe pode assumir um ticket.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
    if (ticket.claimed_by) {
      await interaction.reply({
        content: `Este ticket já foi assumido por <@${ticket.claimed_by}>.`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
    db.prepare("UPDATE tickets SET claimed_by = ? WHERE channel_id = ?").run(
      interaction.user.id,
      ticket.channel_id,
    );
    await interaction.reply({
      content: `☑️ ${interaction.user} assumiu este atendimento.`,
    });
    return;
  }

  if (
    interaction.user.id !== ticket.owner_id &&
    !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator) &&
    !isStaff(interaction.guildId, interaction.user.id)
  ) {
    await interaction.reply({
      content: "Somente quem abriu o ticket ou a equipe pode fechá-lo.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (interaction.customId === "amrp:ticket:close") {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("amrp:ticket:close:confirm")
        .setLabel("Confirmar fechamento")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId("amrp:ticket:close:cancel")
        .setLabel("Manter aberto")
        .setStyle(ButtonStyle.Secondary),
    );
    await interaction.reply({
      content: "Tem certeza de que deseja fechar este ticket?",
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (interaction.customId === "amrp:ticket:close:cancel") {
    await interaction.update({
      content: "O ticket continua aberto.",
      components: [],
    });
    return;
  }

  if (interaction.customId === "amrp:ticket:close:confirm") {
    const channel = interaction.channel;
    await channel.send("🔒 Este ticket será excluído em 3 segundos...");
    const deletionDelay = sleep(3000);
    db.prepare(
      "UPDATE tickets SET status = 'closed', closed_at = CURRENT_TIMESTAMP WHERE channel_id = ?",
    ).run(ticket.channel_id);
    await interaction.update({
      content: "Fechando o ticket...",
      components: [],
    });
    await deletionDelay;
    await channel.delete(`Ticket fechado por ${interaction.user.tag}`);
  }
}

function isAdminOnly(command) {
  return new Set([
    "setranking",
    "setticket",
    "setvagas",
    "staff",
    "config",
    "editperfil",
    "pagar",
    "gastovagas",
    "cargoid",
    "resetvagas",
  ]).has(command);
}

async function handleCommand(message) {
  if (!message.guild || message.author.bot) return;
  const settings = getSettings(message.guild.id);
  const content = message.content.trim();
  const isTutorialAlias = /^\+tutorial(?:\s|$)/i.test(content);
  if (!content.startsWith(settings.prefix) && !isTutorialAlias) return;

  const raw = content.startsWith(settings.prefix)
    ? content.slice(settings.prefix.length).trim()
    : content.slice(1).trim();
  if (!raw) return;
  const [commandToken, ...args] = raw.split(/\s+/);
  const command = commandToken.toLowerCase();

  if (command === "p" || command === "perfil") {
    const user = mentionTarget(message) ?? message.author;
    await message.reply({ embeds: [profileEmbed(message.guild, user, settings)] });
    return;
  }

  if (command === "ajuda" || command === "help") {
    const help = new EmbedBuilder()
      .setColor(getEmbedColor(settings))
      .setAuthor({ name: settings.author })
      .setTitle("Comandos — América RP")
      .setDescription(
        [
          `**Jogadores**`,
          `\`${settings.prefix}p [@jogador]\` — mostra um perfil.`,
          `\`${settings.prefix}ranking\` — mostra o Top 10 geral.`,
          `\`${settings.prefix}vagas\` ou \`${settings.prefix}lista\` — mostra as 50 vagas do evento atual.`,
          `\`${settings.prefix}chavepix\` — mostra a chave PIX para copiar.`,
          "",
          "**Equipe (administrador ou staff)**",
          `\`${settings.prefix}tutorial\` ou \`+tutorial\` — mostra o passo a passo do diário.`,
          `\`${settings.prefix}v @jogador\` — registra somente uma vitória.`,
          `\`${settings.prefix}k @jogador [quantidade]\` — registra kills e adiciona R$ 3,00 por kill à carteira.`,
          `\`${settings.prefix}d @jogador\` — confirma a vaga paga, soma +1 diário jogado, entrega o cargo e reserva a próxima posição de 1 a 50. Dentro do carrinho, a menção é opcional.`,
          "",
          "**Administradores**",
          `\`${settings.prefix}setranking\` — publica e tenta fixar o painel do ranking.`,
          `\`${settings.prefix}setticket\` — publica o painel de suporte.`,
          `\`${settings.prefix}setvagas\` — publica o painel de compra de vagas.`,
          `\`${settings.prefix}staff adicionar|remover @jogador\` — gerencia a equipe autorizada.`,
          `\`${settings.prefix}cargoid [id]\` — consulta ou troca o cargo entregue ao confirmar uma vaga.`,
          `\`${settings.prefix}resetvagas\` — pede confirmação antes de zerar a lista do evento.`,
          `\`${settings.prefix}editperfil @jogador [vitorias|kills|carteira|diarios|gasto] [valor]\` — define um dado do perfil.`,
          `\`${settings.prefix}gastovagas @jogador [valor]\` — acrescenta um gasto em vagas ao perfil.`,
          `\`${settings.prefix}pagar @jogador [valor]\` — desconta um pagamento do saldo (não permite saldo negativo).`,
          `\`${settings.prefix}config ...\` — altera prefixo, embeds, emojis, canal e fuso.`,
        ].join("\n"),
      )
      .setFooter({
        text: `Prefixo atual: ${settings.prefix} • Ranking diário: 00:00 (${settings.timezone})`,
      });
    await message.reply({ embeds: [help] });
    return;
  }

  if (command === "tutorial") {
    if (!canManageDiary(message.member, message.author.id)) {
      await message.reply(
        "Este comando é exclusivo para administradores e membros cadastrados da staff.",
      );
      return;
    }
    const prefix = settings.prefix;
    const tutorial = new EmbedBuilder()
      .setColor(0xff0000)
      .setTitle("Como Realizar um Diário - América RP")
      .addFields(
        {
          name: "○ 🚀 Passo 1: Preparação Pré-Evento",
          value: [
            "• Exclua o cargo do diário anterior.",
            "• Crie o cargo do novo diário com o nome **América Diário 1, 2, 3...**, aumentando o número conforme os diários realizados.",
            "• Dê ao novo cargo permissão para ver os canais da categoria **Confirmados**.",
            `• Configure o cargo que o bot entregará usando \`${prefix}cargoid ID_DO_CARGO\`.`,
            `• Limpe a lista do evento anterior com \`${prefix}resetvagas\` e confirme a ação. A contagem volta para **0/50**.`,
          ].join("\n"),
        },
        {
          name: "○ 🛒 Passo 2: Gerenciamento e Confirmação de Vagas",
          value: [
            "• O jogador clica em **Comprar Vaga** e recebe um carrinho privado `🛒・nome` na categoria **Carrinho's Vagas**.",
            "• Após o jogador enviar o comprovante, confira manualmente o recebimento do PIX de **R$ 6,00**.",
            `• Confirme com \`${prefix}d @jogador\` no carrinho ou em outro canal do servidor.`,
            "• O bot renomeia o canal para `✅️・nome`, entrega o cargo configurado e adiciona o jogador à lista de confirmados, numerada de 1 a 50.",
            "• Cada confirmação válida também soma **+1 diário jogado** ao perfil.",
            `• Consulte as vagas confirmadas a qualquer momento com \`${prefix}vagas\`.`,
          ].join("\n"),
        },
        {
          name: "○ 🎮 Passo 3: Durante e Após a Partida",
          value: [
            "• Colete e confira a gravação obrigatória para verificar as kills de cada jogador.",
            `• Registre o campeão com \`${prefix}v @vencedor\`: adiciona **+1 vitória** ao perfil e ao ranking, sem alterar a contagem de diários.`,
            `• Registre as eliminações com \`${prefix}k @jogador [quantidade]\`: adiciona as kills e calcula **R$ 3,00 por kill** na carteira.`,
          ].join("\n"),
        },
        {
          name: "○ 💰 Passo 4: Premiação e Pagamentos",
          value: [
            "• Oriente os vencedores e os jogadores do Top 30 a solicitar o prêmio abrindo um ticket pelo painel **Suporte**.",
            `• Confira o saldo acumulado após registrar as kills usando \`${prefix}p @jogador\`.`,
            "• Depois de fazer a transferência do prêmio por kills, atualize a carteira com:",
            `\`${prefix}pagar @jogador [valor pago]\`.`,
          ].join("\n"),
        },
      )
      .setFooter({ text: "Equipe Administrativa - América RP" });
    await message.reply({ embeds: [tutorial] });
    return;
  }

  if (command === "ranking") {
    await message.reply({ embeds: [rankingEmbed(message.guild, settings)] });
    return;
  }

  if (
    command === "v" ||
    command === "k"
  ) {
    if (!canManageDiary(message.member, message.author.id)) {
      await message.reply(
        "Este comando é exclusivo para administradores e membros cadastrados da staff.",
      );
      return;
    }
    const target = mentionTarget(message);
    if (!target || target.bot) {
      await message.reply(`Mencione um jogador. Exemplo: \`${settings.prefix}${command} @jogador\`.`);
      return;
    }

    if (command === "v") {
      const dayKey = toDayKey(new Date(), settings.timezone);
      const update = db.transaction(() => {
        ensureProfile(message.guild.id, target.id);
        db.prepare(
          "UPDATE profiles SET wins = wins + 1 WHERE guild_id = ? AND user_id = ?",
        ).run(message.guild.id, target.id);
        db.prepare(
          "INSERT INTO stats_events (guild_id, user_id, event_type, amount, day_key) VALUES (?, ?, 'win', 1, ?)",
        ).run(message.guild.id, target.id, dayKey);
      });
      update();
      await message.reply(`🏆 Vitória registrada para <@${target.id}>.`);
      return;
    }

    if (command === "k") {
      const quantity = parsePositiveInteger(args[1], 1, 10_000);
      if (quantity === null) {
        await message.reply("Informe uma quantidade inteira entre 1 e 10.000.");
        return;
      }
      const dayKey = toDayKey(new Date(), settings.timezone);
      const update = db.transaction(() => {
        ensureProfile(message.guild.id, target.id);
        db.prepare(
          "UPDATE profiles SET kills = kills + ?, wallet_cents = wallet_cents + ? WHERE guild_id = ? AND user_id = ?",
        ).run(quantity, quantity * 300, message.guild.id, target.id);
        db.prepare(
          "INSERT INTO stats_events (guild_id, user_id, event_type, amount, day_key) VALUES (?, ?, 'kill', ?, ?)",
        ).run(message.guild.id, target.id, quantity, dayKey);
      });
      update();
      await message.reply(
        `${settings.emojis.kill} ${quantity} kill(s) registrado(s) para <@${target.id}>. Carteira: +${formatMoney(quantity * 300)}.`,
      );
      return;
    }

  }

  if (command === "d") {
    if (!canManageDiary(message.member, message.author.id)) {
      await message.reply("Este comando é exclusivo para administradores e membros cadastrados da staff.");
      return;
    }
    let target = mentionTarget(message);
    if (!target) {
      const cart = db
        .prepare(
          "SELECT owner_id FROM vacancy_carts WHERE channel_id = ? AND guild_id = ? AND status = 'open'",
        )
        .get(message.channel.id, message.guild.id);
      if (cart) {
        target = await client.users.fetch(cart.owner_id).catch(() => null);
      }
    }
    await confirmVacancy(message, target);
    return;
  }

  if (command === "vagas" || command === "lista") {
    await showConfirmedVacancies(message);
    return;
  }

  if (command === "chavepix") {
    await message.reply(`Chave PIX para copiar:\n\`${PIX_KEY}\``);
    return;
  }

  if (isAdminOnly(command)) {
    if (!isAdmin(message.member)) {
      await message.reply("Este comando é exclusivo para administradores.");
      return;
    }
  }

  if (command === "setranking") {
    await setRanking(message, settings);
    return;
  }

  if (command === "setticket") {
    await message.channel.send(ticketPanel(settings));
    await message.reply("Painel de suporte publicado.");
    return;
  }

  if (command === "setvagas") {
    await message.channel.send(vacancyPanel(settings));
    await message.reply("Painel de compra de vagas publicado.");
    return;
  }

  if (command === "cargoid") {
    const roleId = args[0];
    if (!roleId) {
      await message.reply(
        `Cargo atual: <@&${settings.dailyRoleId}> (\`${settings.dailyRoleId}\`). Para trocar: \`${settings.prefix}cargoid [id_do_cargo]\`.`,
      );
      return;
    }
    if (!/^\d{17,20}$/.test(roleId)) {
      await message.reply("Informe um ID de cargo válido, com 17 a 20 dígitos.");
      return;
    }
    const role = await message.guild.roles.fetch(roleId).catch(() => null);
    if (!role || role.id === message.guild.roles.everyone.id) {
      await message.reply("Não encontrei esse cargo neste servidor.");
      return;
    }
    setSetting(message.guild.id, "dailyRoleId", role.id);
    await message.reply(`Cargo dos próximos confirmados atualizado para **${role.name}**.`);
    return;
  }

  if (command === "resetvagas") {
    if (vacancyConfirmationLocks.has(message.guild.id)) {
      await message.reply("Há uma confirmação de vaga em andamento. Tente o reset novamente em instantes.");
      return;
    }
    await message.reply({
      content: `Confirme para remover os confirmados da lista do evento atual. Isto **não remove os cargos já entregues** e não cancela carrinhos em aberto. Total atual: ${
        db
          .prepare("SELECT COUNT(*) AS total FROM confirmed_vacancies WHERE guild_id = ?")
          .get(message.guild.id).total
      }/${VACANCY_CAPACITY}.`,
      components: [resetVacanciesActions(message.author.id)],
    });
    return;
  }

  if (command === "staff") {
    const action = (args[0] ?? "").toLowerCase();
    if (["adicionar", "add"].includes(action)) {
      const target = mentionTarget(message);
      if (!target || target.bot) {
        await message.reply(`Uso: \`${settings.prefix}staff adicionar @jogador\`.`);
        return;
      }
      db.prepare(
        "INSERT OR IGNORE INTO staff_members (guild_id, user_id, added_by) VALUES (?, ?, ?)",
      ).run(message.guild.id, target.id, message.author.id);
      await message.reply(`<@${target.id}> pode usar os comandos operacionais da staff: \`.v\`, \`.k\`, \`.d\` (confirmar vaga) e \`.diario\`.`);
      return;
    }
    if (["remover", "remove"].includes(action)) {
      const target = mentionTarget(message);
      if (!target) {
        await message.reply(`Uso: \`${settings.prefix}staff remover @jogador\`.`);
        return;
      }
      const result = db
        .prepare("DELETE FROM staff_members WHERE guild_id = ? AND user_id = ?")
        .run(message.guild.id, target.id);
      await message.reply(
        result.changes
          ? `<@${target.id}> removido(a) da staff.`
          : `<@${target.id}> não estava na lista da staff.`,
      );
      return;
    }
    if (["listar", "list"].includes(action)) {
      const members = db
        .prepare("SELECT user_id FROM staff_members WHERE guild_id = ? ORDER BY added_at")
        .all(message.guild.id);
      await message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(getEmbedColor(settings))
            .setTitle("Staff cadastrada")
            .setDescription(
              members.length
                ? members.map((member) => `• <@${member.user_id}>`).join("\n")
                : "Nenhum membro foi cadastrado.",
            ),
        ],
      });
      return;
    }
    await message.reply(
      `Uso: \`${settings.prefix}staff adicionar @jogador\`, \`${settings.prefix}staff remover @jogador\` ou \`${settings.prefix}staff listar\`.`,
    );
    return;
  }

  if (command === "editperfil") {
    const target = mentionTarget(message);
    const field = (args[1] ?? "").toLowerCase();
    const value = args[2];
    if (!target || value === undefined) {
      await message.reply(
        `Uso: \`${settings.prefix}editperfil @jogador [vitorias|kills|carteira|diarios|gasto] [valor]\`.`,
      );
      return;
    }
    const numericFields = {
      vitorias: "wins",
      vitoria: "wins",
      wins: "wins",
      kills: "kills",
      diarios: "diaries",
      diario: "diaries",
      carteira: "wallet_cents",
      saldo: "wallet_cents",
      gasto: "spent_cents",
      gastos: "spent_cents",
      vagas: "spent_cents",
    };
    const column = numericFields[field];
    if (!column) {
      await message.reply("Campo inválido. Use vitorias, kills, carteira, diarios ou gasto.");
      return;
    }
    const centsField = column === "wallet_cents" || column === "spent_cents";
    const parsed = centsField
      ? parseMoneyToCents(value, true)
      : /^\d+$/.test(value)
        ? Number(value)
        : null;
    if (
      parsed === null ||
      !Number.isSafeInteger(parsed) ||
      parsed < 0 ||
      parsed > (centsField ? 100_000_000_000 : 1_000_000_000)
    ) {
      await message.reply(
        centsField
          ? "Informe um valor monetário válido e igual ou maior que zero (ex.: `25,50`)."
          : "Informe um número inteiro igual ou maior que zero.",
      );
      return;
    }
    ensureProfile(message.guild.id, target.id);
    db.prepare(`UPDATE profiles SET ${column} = ? WHERE guild_id = ? AND user_id = ?`).run(
      parsed,
      message.guild.id,
      target.id,
    );
    await message.reply(
      `Perfil de <@${target.id}> atualizado: **${field}** = ${centsField ? formatMoney(parsed) : parsed}.`,
    );
    return;
  }

  if (command === "gastovagas") {
    const target = mentionTarget(message);
    const amount = parseMoneyToCents(args[1] ?? "");
    if (!target || amount === null) {
      await message.reply(
        `Uso: \`${settings.prefix}gastovagas @jogador [valor]\` (ex.: \`${settings.prefix}gastovagas @jogador 20,00\`).`,
      );
      return;
    }
    ensureProfile(message.guild.id, target.id);
    db.prepare(
      "UPDATE profiles SET spent_cents = spent_cents + ? WHERE guild_id = ? AND user_id = ?",
    ).run(amount, message.guild.id, target.id);
    await message.reply(
      `Gasto de ${formatMoney(amount)} adicionado ao perfil de <@${target.id}>.`,
    );
    return;
  }

  if (command === "pagar") {
    const target = mentionTarget(message);
    const amount = parseMoneyToCents(args[1] ?? "");
    if (!target || amount === null) {
      await message.reply(
        `Uso: \`${settings.prefix}pagar @jogador [valor]\` (ex.: \`${settings.prefix}pagar @jogador 15,00\`).`,
      );
      return;
    }
    ensureProfile(message.guild.id, target.id);
    const pay = db.transaction(() => {
      const result = db
        .prepare(
          "UPDATE profiles SET wallet_cents = wallet_cents - ? WHERE guild_id = ? AND user_id = ? AND wallet_cents >= ?",
        )
        .run(amount, message.guild.id, target.id, amount);
      if (result.changes === 0) return false;
      db.prepare(
        "INSERT INTO payments (guild_id, user_id, amount_cents, paid_by) VALUES (?, ?, ?, ?)",
      ).run(message.guild.id, target.id, amount, message.author.id);
      return true;
    });
    if (!pay()) {
      await message.reply(
        `Pagamento não registrado: o saldo de <@${target.id}> é insuficiente. Consulte com \`${settings.prefix}p @jogador\`.`,
      );
      return;
    }
    const profile = getProfile(message.guild.id, target.id);
    await message.reply(
      `Pagamento de ${formatMoney(amount)} descontado da carteira de <@${target.id}>. Saldo restante: ${formatMoney(profile.wallet_cents)}.`,
    );
    return;
  }

  if (command === "config") {
    const setting = (args[0] ?? "").toLowerCase();
    const value = args.slice(1).join(" ").trim();
    if (setting === "ajuda" || setting === "help" || !setting) {
      await message.reply(
        [
          "**Configurações disponíveis**",
          `\`${settings.prefix}config prefix [prefixo]\` — troca o prefixo dos comandos.`,
          `\`${settings.prefix}config embedcolor [#hex]\` — troca a cor das embeds.`,
          `\`${settings.prefix}config emoji [vitoria|kill|carteira|ranking|perfil|vaga|suporte|fechar|assumir] [emoji]\` — troca um emoji de perfil ou botão.`,
          `\`${settings.prefix}config autor [texto]\` — troca o autor das embeds.`,
          `\`${settings.prefix}config canalranking #canal\` — define o canal do ranking diário.`,
          `\`${settings.prefix}config fuso [fuso IANA]\` — configura o fuso do agendamento diário.`,
          `\`${settings.prefix}config mostrar\` — exibe a configuração atual.`,
        ].join("\n"),
      );
      return;
    }
    if (setting === "mostrar" || setting === "show") {
      const current = getSettings(message.guild.id);
      await message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(getEmbedColor(current))
            .setTitle("Configuração América RP")
            .addFields(
              { name: "Prefixo", value: `\`${current.prefix}\``, inline: true },
              { name: "Cor", value: current.embedColor, inline: true },
              { name: "Autor", value: current.author, inline: true },
              { name: "Fuso", value: current.timezone, inline: true },
              {
                name: "Canal do ranking",
                value: current.rankingChannelId
                  ? `<#${current.rankingChannelId}>`
                  : "Não definido",
                inline: true,
              },
              {
                name: "Cargo do diário",
                value: `<@&${current.dailyRoleId}>`,
                inline: true,
              },
            ),
        ],
      });
      return;
    }
    if (setting === "prefix") {
      if (!value || value.length > 5 || /\s/.test(value)) {
        await message.reply("Informe um prefixo de 1 a 5 caracteres, sem espaços.");
        return;
      }
      setSetting(message.guild.id, "prefix", value);
      await message.reply(`Prefixo atualizado para \`${value}\`.`);
      return;
    }
    if (setting === "embedcolor" || setting === "cor") {
      if (!/^#[0-9a-fA-F]{6}$/.test(value)) {
        await message.reply("Use um código hexadecimal no formato `#RRGGBB` (ex.: `#B5121B`).");
        return;
      }
      setSetting(message.guild.id, "embedColor", value.toUpperCase());
      await message.reply(`Cor das embeds atualizada para **${value.toUpperCase()}**.`);
      return;
    }
    if (setting === "autor" || setting === "author") {
      if (!value || value.length > 256) {
        await message.reply("O autor deve ter entre 1 e 256 caracteres.");
        return;
      }
      setSetting(message.guild.id, "author", value);
      await message.reply(`Autor das embeds atualizado para **${value}**.`);
      return;
    }
    if (setting === "emoji") {
      const [rawName, ...emojiParts] = args.slice(1);
      const name = (rawName ?? "").toLowerCase();
      const emoji = emojiParts.join(" ").trim();
      const aliases = {
        vitoria: "vitoria",
        vitória: "vitoria",
        victory: "vitoria",
        wins: "vitoria",
        kill: "kill",
        kills: "kill",
        carteira: "carteira",
        wallet: "carteira",
        vaga: "vaga",
        vagas: "vaga",
        comprarvaga: "vaga",
        ranking: "ranking",
        perfil: "perfil",
        meuperfil: "perfil",
        suporte: "suporte",
        ticket: "suporte",
        fechar: "fechar",
        close: "fechar",
        assumir: "assumir",
        claim: "assumir",
      };
      const key = aliases[name];
      const isUnicodeEmoji = /\p{Extended_Pictographic}/u.test(emoji);
      const isCustomEmoji = /^<a?:\w+:\d+>$/.test(emoji);
      if (!key || (!isUnicodeEmoji && !isCustomEmoji)) {
        await message.reply(
          "Uso: `.config emoji [vitoria|kill|carteira|ranking|perfil|vaga|suporte|fechar|assumir] [emoji]`.",
        );
        return;
      }
      setSetting(message.guild.id, `emoji.${key}`, emoji);
      await message.reply(`Emoji **${key}** atualizado para ${emoji}.`);
      return;
    }
    if (["canalranking", "canal-diario", "rankingchannel"].includes(setting)) {
      const channel = message.mentions.channels.first();
      if (value.toLowerCase() === "off" || value.toLowerCase() === "desativar") {
        setSetting(message.guild.id, "rankingChannelId", "");
        await message.reply("Canal de ranking diário removido.");
        return;
      }
      if (!channel || !channel.isTextBased()) {
        await message.reply(
          `Mencione um canal de texto, por exemplo: \`${settings.prefix}config canalranking #ranking\`.`,
        );
        return;
      }
      setSetting(message.guild.id, "rankingChannelId", channel.id);
      await message.reply(`Ranking diário será enviado em ${channel}.`);
      return;
    }
    if (setting === "fuso" || setting === "timezone") {
      if (!value) {
        await message.reply(
          `Uso: \`${settings.prefix}config fuso America/Sao_Paulo\`.`,
        );
        return;
      }
      try {
        new Intl.DateTimeFormat("pt-BR", { timeZone: value }).format(new Date());
      } catch {
        await message.reply("Fuso inválido. Use um nome IANA, como `America/Sao_Paulo`.");
        return;
      }
      setSetting(message.guild.id, "timezone", value);
      scheduleGuild(message.guild);
      await message.reply(`Fuso atualizado. O ranking será enviado às 00:00 em **${value}**.`);
      return;
    }
    await message.reply(
      `Configuração desconhecida. Use \`${settings.prefix}config ajuda\` para ver as opções.`,
    );
  }
}

client.on(Events.MessageCreate, (message) => {
  handleCommand(message).catch(async (error) => {
    console.error("[comando] Erro:", error);
    if (message.channel.isSendable()) {
      await message.reply("Não consegui concluir esse comando. Verifique os parâmetros e as permissões do bot.").catch(() => {});
    }
  });
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (!interaction.inGuild()) return;
    const settings = getSettings(interaction.guildId);

    if (interaction.isButton()) {
      if (interaction.customId === "amrp:ranking") {
        await interaction.reply({
          embeds: [rankingEmbed(interaction.guild, settings)],
          flags: MessageFlags.Ephemeral,
        });
        return;
      }
      if (interaction.customId === "amrp:profile") {
        await interaction.reply({
          embeds: [profileEmbed(interaction.guild, interaction.user, settings)],
          flags: MessageFlags.Ephemeral,
        });
        return;
      }
      if (interaction.customId === "amrp:ticket:create") {
        await createTicket(interaction, settings);
        return;
      }
      if (interaction.customId === "amrp:vagas:buy") {
        await createVacancyCart(interaction, settings);
        return;
      }
      if (interaction.customId.startsWith("amrp:vagas:reset:")) {
        await handleVacancyResetInteraction(interaction);
        return;
      }
      if (interaction.customId.startsWith("amrp:vagas:")) {
        await handleVacancyCartInteraction(interaction, settings);
        return;
      }
      if (interaction.customId.startsWith("amrp:ticket:")) {
        await handleTicketInteraction(interaction, settings);
      }
    }
  } catch (error) {
    console.error("[interação] Erro:", error);
    const payload = {
      content: "Não consegui concluir essa ação. Verifique as permissões do bot e tente novamente.",
      flags: MessageFlags.Ephemeral,
    };
    if (interaction.isRepliable()) {
      if (interaction.deferred || interaction.replied) {
        await interaction.followUp(payload).catch(() => {});
      } else {
        await interaction.reply(payload).catch(() => {});
      }
    }
  }
});

client.once(Events.ClientReady, (readyClient) => {
  console.info(
    `[bot] Conectado como ${readyClient.user.tag} em ${readyClient.guilds.cache.size} servidor(es).`,
  );
  if (readyClient.guilds.cache.size === 0) {
    const requestedPermissions = [
      PermissionFlagsBits.ViewChannel,
      PermissionFlagsBits.SendMessages,
      PermissionFlagsBits.ReadMessageHistory,
      PermissionFlagsBits.EmbedLinks,
      PermissionFlagsBits.ManageChannels,
      PermissionFlagsBits.ManageMessages,
      PermissionFlagsBits.AttachFiles,
      PermissionFlagsBits.UseExternalEmojis,
    ].reduce((permissions, flag) => permissions | flag, 0n);
    const inviteUrl = new URL("https://discord.com/oauth2/authorize");
    inviteUrl.searchParams.set("client_id", readyClient.user.id);
    inviteUrl.searchParams.set("scope", "bot");
    inviteUrl.searchParams.set("permissions", requestedPermissions.toString());
    console.warn(
      `[bot] Nenhum servidor encontrado. Convide o bot pelo link: ${inviteUrl.toString()}`,
    );
  }
  for (const guild of readyClient.guilds.cache.values()) {
    scheduleGuild(guild);
  }
});

client.on(Events.GuildCreate, (guild) => scheduleGuild(guild));

const healthApp = express();
healthApp.disable("x-powered-by");
healthApp.get(["/", "/health"], (_request, response) => {
  response.status(200).type("text/plain").send("OK");
});

const healthPort = Number.parseInt(process.env.PORT ?? "", 10) || 3000;
const healthServer = healthApp.listen(healthPort, "0.0.0.0", () => {
  console.info(`[http] Health endpoint escutando na porta ${healthPort}.`);
});
healthServer.on("error", (error) => {
  console.error("[http] Não foi possível iniciar o endpoint de saúde:", error);
});

for (const signal of ["SIGINT", "SIGTERM"]) {
  process.once(signal, async () => {
    console.info(`[bot] Recebido ${signal}; encerrando.`);
    for (const task of scheduledGuilds.values()) task.stop();
    if (healthServer.listening) {
      await new Promise((resolve) => healthServer.close(resolve));
    }
    await client.destroy();
    db.close();
    process.exit(0);
  });
}

client.login(token).catch((error) => {
  console.error("[bot] Falha ao conectar ao Discord. Confira BOT_TOKEN.", error);
  process.exitCode = 1;
});